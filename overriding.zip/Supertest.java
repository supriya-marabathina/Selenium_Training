package javaTraining;

public class Supertest{
	
	
	void run(){
		System.out.println("coming to supertest class");
	}
}
