package javaTraining;
class overriding extends Supertest{
	void run(){
		System.out.println("coming to overriding class");
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Supertest s1 = new Supertest(); 
		overriding s2=new overriding();
		s2.run();
		s1.run();		   
}
}